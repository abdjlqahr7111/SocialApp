import QtQuick 2.15
import QtQuick.Controls 2.15
import QtMultimedia 5.15 // المكتبة المسؤولة عن معالجة الفيديو في Qt
import com.socialapp.camera 1.0 // استيراد كود الـ C++ الخاص بنا

Rectangle {
    id: roomRoot
    color: "#000000"

    // استدعاء محرك الكاميرا الذي صممناه بـ C++
    CameraHandler {
        id: camHandler
    }

    // عنصر عرض الفيديو (هنا ستظهر صورة الكاميرا)
    VideoOutput {
        id: videoOutput
        anchors.fill: parent
        source: camHandler // ربط مصدر الفيديو بمحرك الكاميرا
        fillMode: VideoOutput.PreserveAspectCrop // ملء الشاشة مع الحفاظ على الأبعاد
    }

    // زر إغلاق الغرفة
    Button {
        text: "إغلاق الغرفة"
        anchors.top: parent.top
        anchors.left: parent.left
        anchors.margins: 20
        onClicked: {
            camHandler.stopCamera() // إغلاق الكاميرا عند الخروج
            console.log("تم إغلاق الغرفة")
        }
    }

    // بدء الكاميرا بمجرد تحميل الغرفة
    Component.onCompleted: {
        camHandler.startCamera()
    }
}
