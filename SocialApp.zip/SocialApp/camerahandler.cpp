#include "camerahandler.h"

CameraHandler::CameraHandler(QObject *parent) : QObject(parent)
{
    // اختيار الكاميرا الافتراضية للجهاز
    m_camera = new QCamera(QMediaDevices::defaultVideoInput());

    // في Qt6، لربط الكاميرا بـ VideoOutput في QML، نحتاج إلى جلسة التقاط (Capture Session)
    m_captureSession = new QMediaCaptureSession(this);
    m_captureSession->setCamera(m_camera);
}

void CameraHandler::startCamera()
{
    // التحقق من وجود الكاميرا قبل محاولة تشغيلها
    if (m_camera) {
        m_camera->start(); // تفعيل عدسة الكاميرا وبدء البث
    }
}

void CameraHandler::stopCamera()
{
    // التحقق من وجود الكاميرا قبل محاولة إيقافها
    if (m_camera) {
        m_camera->stop(); // إغلاق الكاميرا لتوفير الطاقة
    }
}
