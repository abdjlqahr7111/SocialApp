import QtQuick 2.15
import QtQuick.Controls 2.15
import "components" // استدعاء مجلد المكونات الذي يحتوي على القصص

ApplicationWindow {
    visible: true
    width: 360
    height: 640
    title: qsTr("تطبيق التواصل الاجتماعي")
    color: "#121212"

    // الشريط العلوي للتطبيق
    header: ToolBar {
        background: Rectangle {
            color: "#1e1e1e"
        }
        Row {
            anchors.centerIn: parent
            Label {
                text: "الرئيسية"
                color: "#ffffff"
                font.pixelSize: 20
                font.bold: true
            }
        }
    }

    // تصميم محتوى الشاشة الأساسي
    Column {
        anchors.fill: parent
        anchors.topMargin: 15 // مسافة بسيطة من الأعلى
        spacing: 20
// أضف هذا الجزء داخل الـ Column في main.qml قبل StoryTray
TextField {
    placeholderText: "البحث عن غرف..."
    width: parent.width - 30
    anchors.horizontalCenter: parent.horizontalCenter
    background: Rectangle {
        color: "#2c2c2c"
        radius: 10
    }
    color: "#ffffff"
}

        // استدعاء شريط القصص
        StoryTray {
            width: parent.width
        }

        // قائمة غرف الفيديو الجديدة
        // داخل main.qml استبدل الـ ListView بهذا الكود:
SwipeView {
    id: view
    width: parent.width
    height: 400
    currentIndex: 1 // الغرفة الافتراضية

    RoomPage { /* الغرفة 1 */ }
    RoomPage { /* الغرفة 2 */ }
    RoomPage { /* الغرفة 3 */ }
}
    }
}
