#ifndef CAMERAHANDLER_H
#define CAMERAHANDLER_H

#include <QObject>
#include <QCamera>
#include <QMediaCaptureSession>
// تم إضافة هذا السطر ليكون الكود متوافقاً تماماً مع Qt6
#include <QMediaDevices>

class CameraHandler : public QObject {
    Q_OBJECT
public:
    explicit CameraHandler(QObject *parent = nullptr);

    // دوال نستخدمها من داخل QML
    Q_INVOKABLE void startCamera();
    Q_INVOKABLE void stopCamera();

private:
    QCamera *m_camera;
    QMediaCaptureSession *m_captureSession;
};

#endif
