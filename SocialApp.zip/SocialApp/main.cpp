#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include "camerahandler.h"
#include "databasehandler.h"

// إضافة مكتبة التعامل مع صلاحيات أندرويد
#ifdef Q_OS_ANDROID
#include <QtAndroidExtras/QtAndroid>
#endif

int main(int argc, char *argv[])
{
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
    QGuiApplication app(argc, argv);

    // 1. طلب صلاحيات الكاميرا والميكروفون عند التشغيل (لأندرويد فقط)
#ifdef Q_OS_ANDROID
    const QVector<QString> permissions({"android.permission.CAMERA", "android.permission.RECORD_AUDIO"});

    for(const QString &permission : permissions) {
        auto result = QtAndroid::checkPermission(permission);
        if(result == QtAndroid::PermissionResult::Denied) {
            QtAndroid::requestPermissionsSync(QStringList({permission}));
        }
    }
#endif

    // 2. تسجيل كود الـ C++ ليكون مرئياً في QML
    qmlRegisterType<CameraHandler>("com.socialapp.camera", 1, 0, "CameraHandler");
    qmlRegisterType<DatabaseHandler>("com.socialapp.db", 1, 0, "DatabaseHandler");

    QQmlApplicationEngine engine;

    // تحميل الواجهة الرئيسية من الموارد qrc:/
    const QUrl url(QStringLiteral("qrc:/ui/main.qml"));

    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)
            QCoreApplication::exit(-1);
    }, Qt::QueuedConnection);

    engine.load(url);

    return app.exec();
}
