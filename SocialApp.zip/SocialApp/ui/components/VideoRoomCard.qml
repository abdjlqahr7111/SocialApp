import QtQuick 2.15
import QtQuick.Controls 2.15

Rectangle {
    width: parent.width - 30
    height: 120
    color: "#1e1e1e"
    radius: 15
    anchors.horizontalCenter: parent.horizontalCenter
    border.color: "#333333"

    Row {
        anchors.fill: parent
        padding: 15
        spacing: 15

        // أيقونة الغرفة (دائرة الفيديو)
        Rectangle {
            width: 90
            height: 90
            radius: 10
            color: "#333333"
            
            Text {
                anchors.centerIn: parent
                text: "📹"
                font.pixelSize: 30
            }
        }

        // تفاصيل الغرفة
        Column {
            spacing: 5
            anchors.verticalCenter: parent.verticalCenter

            Label {
                text: "غرفة نقاش تقني" // اسم الغرفة
                color: "#ffffff"
                font.pixelSize: 18
                font.bold: true
            }

            Label {
                text: "12 شخصاً يشاهدون الآن"
                color: "#aaaaaa"
                font.pixelSize: 14
            }

            // زر الانضمام
            Button {
                text: "انضم الآن"
                background: Rectangle {
                    color: "#e1306c"
                    radius: 5
                }
                onClicked: {
                    console.log("جارٍ الاتصال بغرفة الفيديو...")
                }
            }
        }
    }
}
