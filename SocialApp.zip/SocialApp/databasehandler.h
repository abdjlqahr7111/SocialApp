#ifndef DATABASEHANDLER_H
#define DATABASEHANDLER_H

#include <QObject>
#include <QtSql>
#include <QVariantList>

class DatabaseHandler : public QObject
{
    Q_OBJECT
public:
    explicit DatabaseHandler(QObject *parent = nullptr);

    // دوال لاستخدامها من داخل QML لجلب البيانات
    Q_INVOKABLE void fetchStories(); // دالة لجلب القصص (تم تعديلها لتلائم الكود في QML)

signals:
    // إشارة يتم إرسالها عند انتهاء جلب البيانات لتحديث الواجهة
    void storiesReady(QVariantList stories);

private:
    QSqlDatabase m_db;
    void initDatabase(); // دالة خاصة لإنشاء/الاتصال بالقاعدة
};

#endif
