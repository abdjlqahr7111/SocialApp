import QtQuick 2.15
import QtQuick.Controls 2.15
import com.socialapp.db 1.0 // استيراد مكتبة قاعدة البيانات

ListView {
    id: storyTray
    height: 100
    orientation: ListView.Horizontal
    spacing: 15
    padding: 10

    // إنشاء كائن قاعدة البيانات
    DatabaseHandler {
        id: dbHandler
    }

    // هنا نستخدم ListModel لتخزين القصص التي نجلبها من القاعدة
    model: ListModel { id: storyModel }

    delegate: Rectangle {
        width: 70
        height: 70
        radius: 35
        color: "#333333"
        border.color: "#e1306c"
        border.width: 2
        
        Text {
            anchors.centerIn: parent
            text: model.name // سيتم جلب الاسم من القاعدة
            color: "white"
        }
    }

    // عند تحميل الشريط، نطلب البيانات من قاعدة البيانات
    Component.onCompleted: {
        refreshStories()
    }

    function refreshStories() {
        // TODO: سيتم استبدال هذا الجزء لاحقاً لجلب البيانات الحقيقية من C++
        // عندما تصبح دالة dbHandler.getStories() جاهزة.
        
        // حالياً، نضيف بيانات تجريبية للتأكد من عمل الشكل:
        storyModel.clear();
        storyModel.append({"name": "قصة 1"});
        storyModel.append({"name": "قصة 2"});
        storyModel.append({"name": "قصة 3"});
        
        // هذا السطر كان موجوداً في الكود الأصلي لديك، لكن الدالة غير موجودة في الـ h المرفق حالياً:
        // dbHandler.fetchStories(); 
    }
}
