# إعدادات المشروع العامة
QT += core gui widgets androidextras multimedia sql

TARGET = SocialApp
TEMPLATE = app

CONFIG += c++17

# ملفات المصدر C++
SOURCES += main.cpp \
           camerahandler.cpp \
           databasehandler.cpp

# ملفات الترويسة C++
HEADERS += camerahandler.h \
           databasehandler.h

# ملفات الموارد (QML والقصص)
RESOURCES += qml.qrc

# إعدادات خاصة بمنصة أندرويد
android {
    ANDROID_PACKAGE_SOURCE_DIR = $$PWD/android
}

# الملفات الأخرى (للتنظيم داخل Qt Creator)
DISTFILES += \
    android/AndroidManifest.xml \
    ui/main.qml \
    ui/RoomPage.qml \
    ui/components/StoryTray.qml \
    ui/components/VideoRoomCard.qml
