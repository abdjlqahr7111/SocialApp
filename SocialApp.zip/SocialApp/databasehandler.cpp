#include "databasehandler.h"
#include <QDebug>
#include <QSqlError>

DatabaseHandler::DatabaseHandler(QObject *parent) : QObject(parent)
{
    // تهيئة قاعدة البيانات عند إنشاء الكائن
    initDatabase();
}

void DatabaseHandler::initDatabase()
{
    // استخدام SQLite كقاعدة بيانات محلية
    if (QSqlDatabase::contains("qt_sql_default_connection")) {
        m_db = QSqlDatabase::database("qt_sql_default_connection");
    } else {
        m_db = QSqlDatabase::addDatabase("QSQLITE");
        // سيتم إنشاء الملف في مجلد بيانات التطبيق على الهاتف
        m_db.setDatabaseName("social_app.db");
    }

    if (!m_db.open()) {
        qDebug() << "Error: Could not connect to database:" << m_db.lastError().text();
    } else {
        // إنشاء الجدول إذا لم يكن موجوداً
        QSqlQuery query;
        QString createTableQuery = "CREATE TABLE IF NOT EXISTS stories ("
                                   "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                                   "name TEXT NOT NULL, "
                                   "image_url TEXT)"; // تم تغيير image إلى image_url للأوضح

        if (!query.exec(createTableQuery)) {
            qDebug() << "Error: Failed to create table:" << query.lastError().text();
        }
    }
}

// دالة جلب البيانات (تم تعديلها لتكون غير متزامنة)
void DatabaseHandler::fetchStories()
{
    QVariantList list;
    QSqlQuery query("SELECT name FROM stories ORDER BY id DESC"); // جلب أحدث القصص

    while (query.next()) {
        // في هذا المثال البسيط، نعيد قائمة أسماء فقط.
        // مستقبلاً، يمكننا إعادة QVariantMap لكل قصة تحتوي على (name, url)
        list.append(query.value(0).toString());
    }

    // محاكاة تأخير بسيط للشبكة (اختياري، لحين ربطها بقاعدة بيانات حقيقية)
    // QThread::sleep(1); 

    // إرسال الإشارة ومعها البيانات ليتم استقبالها في QML
    emit storiesReady(list);
}

// دالة إضافة قصة (تم الإبقاء عليها كما هي، مع تحسين بسيط في الاستعلام)
bool DatabaseHandler::addStory(QString name, QString imageUrl)
{
    if (!m_db.isOpen()) return false;

    QSqlQuery query;
    query.prepare("INSERT INTO stories (name, image_url) VALUES (:name, :image_url)");
    query.bindValue(":name", name);
    query.bindValue(":image_url", imageUrl);

    if (!query.exec()) {
        qDebug() << "Error: Failed to insert story:" << query.lastError().text();
        return false;
    }
    return true;
}
